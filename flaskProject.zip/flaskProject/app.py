
from flask import Flask, render_template, request
import openai


app = Flask(__name__)


openai.api_key = 'Enter Your Key Here'


def chatgpt_query(term):
    try:
        # Define the prompt to be used for ChatGPT
        prompt1 = f"Define {term} and provide a one-paragraph summary."

        # Make the API call
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Your an expert in IT terminology."},
                {"role": "system", "content": f"{prompt1}"}
            ]
        )

    # Check if 'choices' is present in the response
        if 'choices' in response and len(response['choices']) > 0:
            answer = response.choices[0].message.content
            return answer
        else:
            return "No response text found in the API response."

    except Exception as e:
        return f"An error occurred: {str(e)}"


@app.route("/", methods=["GET", "POST"])
def index():
    term = ""
    definition = ""

    if request.method == "POST":
        term = request.form["term"]
        definition = chatgpt_query(term)

    return render_template("index.html", term=term, definition=definition)


if __name__ == "__main__":
    app.run()
